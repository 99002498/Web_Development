//Example for creating JSON Rest server....
const app = require('express')();
const parser = require("body-parser");
//const cors = require('cors');
const fs = require("fs");
const dir = __dirname;

//middleware....
app.use(parser.urlencoded({ extended: true }));
app.use(parser.json());
//app.use(cors());//use the Cors so that it enables CORS...

//GET(Reading), POST(Adding), PUT(Updating), DELETE(Deleting) data....
let hotels = [];//blank array...

function readData(){
    const filename = "data.json";//new file... 
    const jsonContent = fs.readFileSync(filename, 'utf-8'); //unicode Transformation Format used for encoding of data
    hotels = JSON.parse(jsonContent);
}

function saveData(){
    const filename = "data.json";
    const jsonData = JSON.stringify(hotels);
    fs.writeFileSync(filename, jsonData, 'utf-8');
}
app.get("/hotels", (req, res)=>{
    readData();
    res.send(JSON.stringify(hotels));    
})

app.get("/hotels/:id", (req, res)=>{
    const newName = req.params.id;
    if(hotels.length == 0){
        readData();//Fill the array if it is not loaded....
    }
    let foundRec = hotels.find((e) => e.newName == newName);
    if(foundRec == null)
        throw "Hotel not found";
    res.send(JSON.stringify(foundRec))
})

app.put("/hotels", (req, res)=>{
    if(hotels.length == 0)
        readData();//Fill the array if it is not loaded....
    let body = req.body;
    //iterate thro the collection
    for (let index = 0; index < hotels.length; index++) {
        let h1 = hotels[index];
        if (h1.hotelName == body.hotelName) {//find the matching record
            h1.hotelCity = body.hotelCity;
            h1.hotelType = body.hotelType;
            h1.hotelCusine = body.hotelCusine;
            saveData();
            res.send("Hotel updated successfully");
        }
    }
    //update the data
    //exit the function....
})

app.post('/hotels', (req, res)=>{
    if (hotels.length == 0)
        readData();//Fill the array if it is not loaded....
    let body = req.body;//parsed data from the POST...
    hotels.push(body);  
    saveData();//updating to the JSON file...
    res.send("Employee added successfully");
})
app.delete("/hotels/:id", (req, res)=>{
  throw "Do it UR Self!!!!";  
})

app.listen(1234, ()=>{
    console.log("Server available at 1234");
})